# Gamemodstudios Official Logo Pack

This package contains the core branding assets for Gamemodstudios. These files are intended for use in media kits, articles, applications, integrations, and partner announcements.

## 📦 Included Files

### SVG (Vector)

- `gamemodstudios-logo-primary.svg` — Full-color logo.
- `gamemodstudios-logo-mono.svg` — mono version.
- `gamemodstudios-icon.svg` — Symbol/icon only (no text)

### PNG (Raster)

- `gamemodstudios-logo-primary.png`
- `gamemodstudios-logo-mono.png`
- `gamemodstudios-icon.png`

## ✅ Usage Guidelines

- Do **not** edit, recolor, distort, or reformat any logos.
- Maintain clear space equal to the height of the “G” around the logo.
- Use the full-color logo on white or light backgrounds.
- Use the mono-white logo on dark backgrounds.
- The icon may be used independently in contexts where space is limited.

For more details, refer to our [Logos and Usage page](https://gamemodstudios.github.io/logos).

## 📧 Contact & Permissions

For logo usage questions, licensing, or brand-related approvals, email:  
**📩 <gamemodstudios+legal@gmail.com>**

## ⚖️ Trademark Notice

“Gamemodstudios” and the Gamemodstudios logo are trademarks of Gamemodstudios. Unauthorized use is strictly prohibited.

Other brand names/logos appearing alongside Gamemodstudios materials are trademarks of their respective owners.
