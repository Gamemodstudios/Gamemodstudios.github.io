# Gamemodstudios Product Branding Pack

This archive contains official branding assets for Gamemodstudios developer products, including the Gamemodstudios SDK and Gamemodstudios HUB.

These assets are intended for use in integrations, partner tools, modding platforms, and developer-facing documentation.

## 📦 Included Files

### SDK

- `gamemodstudios__sdk.svg` — Official Gamemodstudios SDK logo
- `gamemodstudios_sdk.png` — Gamemodstudios SDK logo

### HUB

- `gamemodstudios__hub.svg` — Official Gamemodstudios HUB logo
- `gamemodstudios__hub.png` — Gamemodstudios HUB logo

## ✅ Usage Guidelines

- Use only in contexts involving official integrations or platform mentions.
- Do **not** modify or combine these logos with other marks.
- Do **not** imply endorsement unless explicitly authorized.
- Keep the logos visually distinct and unobstructed.

For logo requirements and previews, visit:  
🔗 [gamemodstudios.github.io/logos](https://gamemodstudios.github.io/logos)

## 📧 Permissions & Inquiries

For official press use, white-label partnerships, or legal authorization, please contact:  
**📩 <gamemodstudios+legal@gmail.com>**

## ⚖️ Licensing & Trademarks

Gamemodstudios SDK, Gamemodstudios HUB, and the associated branding assets are intellectual property of Gamemodstudios.  
Use of these assets without approval may result in revocation of integration rights.

All rights reserved © Gamemodstudios
